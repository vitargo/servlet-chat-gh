package com.github.di.factory.forTests;

public interface IMyCustomInterface {
}
