package com.github.di.factory.forTests;

public class FirstReliase implements IMyCustomInterface {
}
